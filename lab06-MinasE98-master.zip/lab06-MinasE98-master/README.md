
## UoI-CSE-MYY505 lab06

## First-Name Last-Name

**TODO - Update your name in this readme. Leave 1 space after the ## to preserve the text formating**


## Problem statement:
* Run cache.asm on Mars with Data Cache Simulation Tool and answer the questions in lab06_answers.txt
 
## Files to work on
* `lab06_answers.txt` 
* `cache.asm` 
      
## Running 
* No automatic testing for this lab. Just run Mars interactively.


## Notes
* Make sure your last push is before the deadline. Your last push will be considered as your final submission.
* If you need a deadline extension for any reason, use the [provided form.](https://forms.gle/LVbqsk3yqeNEGtev8)
* Post questions on [Piazza!](https://piazza.com/uoi.gr/fall2019/myy505/home).
