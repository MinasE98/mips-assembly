
## UoI-CSE-MYY505 lab07

## First-Name Last-Name

**TODO - Update your name in this readme. Leave 1 space after the ## to preserve the text formating**


## Problem statement:
* Run exceptions.asm on Mars to understand the exception mechanism.
* Modify the handler to resume execution to the instruction following the one which caused the exception
* Add code to handle bad address and trap exceptions.
 
## Files to work on
* `exceptions.asm` 
      
## Running 
* No automatic testing for this lab. Just run Mars interactively.


## Notes
* Make sure your solution assembles and runs.
* Make sure your last push is before the deadline. Your last push will be considered as your final submission.
* If you need a deadline extension for any reason, use the [provided form.](https://forms.gle/LVbqsk3yqeNEGtev8)
* Post questions on [Piazza!](https://piazza.com/uoi.gr/fall2019/myy505/home).
